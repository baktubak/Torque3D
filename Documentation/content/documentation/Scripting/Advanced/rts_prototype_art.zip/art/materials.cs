
singleton Material(gg_marker)
{
   mapTo = "unmapped_mat";
   diffuseMap[0] = "art/decals/g_marker.png";
   alphaTest = "1";
   alphaRef = "80";
};
