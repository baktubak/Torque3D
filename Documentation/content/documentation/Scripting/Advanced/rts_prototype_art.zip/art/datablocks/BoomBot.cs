//-----------------------------------------------------------------------------
// Torque Game Engine Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

datablock PlayerData(BoomBotData : DefaultPlayerData)
{
   renderFirstPerson = false;
   emap = true;

   airControl = 0.3;

   jetJumpForce       = 8.3 * 10;
   jetJumpEnergyDrain = 0.6;
   jetMinJumpEnergy   = 0;

   maxForwardSpeed = 24;
   jumpForce = 12.3 * 90;

   //className = Armor;
   shapeFile = "art/shapes/actors/BoomBot/BoomBot.dts";

   boundingBox = "1.1 1.2 2.5";
   pickupRadius = 0.75;

   // Damage location details
   boxNormalHeadPercentage = 0.83;
   boxNormalTorsoPercentage = 0.49;
   boxHeadLeftPercentage = 0;
   boxHeadRightPercentage = 1;
   boxHeadBackPercentage = 0;
   boxHeadFrontPercentage = 1;
};