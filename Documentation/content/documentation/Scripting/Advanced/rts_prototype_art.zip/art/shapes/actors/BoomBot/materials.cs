new Material(blue_IB1)
{
   mapTo = "blue_IB1";
   diffuseMap[0] = "blue_IB1";
   normalMap[0] = "blue_IB1PSDbump";
   pixelSpecular[0] = true;
   specular[0] = "1.0 1.0 1.0 1.0";
   specularPower[0] = 32.0;

};


new    Material(blue_IB2)
{
   mapTo = "blue_IB2";
   diffuseMap[0] = "blue_IB2";
   normalMap[0] = "blue_IB2PSDbump";
   pixelSpecular[0] = true;
   specular[0] = "1.0 1.0 1.0 1.0";
   specularPower[0] = 32.0;

};


new Material(blue_IB3)
{
   mapTo = "blue_IB3";
   diffuseMap[0] = "blue_IB3";

};


new Material(blue_IB4)
{
   mapTo = "blue_IB4";
   diffuseMap[0] = "blue_IB4";

};
